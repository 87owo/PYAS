t_list = ['Morris Worm',
          'Nimda',
          'ILOVEYOU',
          'SQL Slammer',
          'Stuxnet',
          'CryptoLocker',
          'Conficker',
          'Tinba',
          'Welchia',
          'Shlayer',
          'Mydoom',
          'Sobig',
          'Klez',
          'WannaCry',
          'Zeus',
          'Code Red',
          'Slammer',
          'CryptoLocker',
          'Sasser',
          'Mimail',
          'Yaha',
          'Swen',
          'Storm Worm',
          'Tanatos',
          'Sircam',
          'Explorezip',
          'Melissa',
          'Flashback',
          'Conficker',
          'X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*',
          'Stuxnet',
          'Torpig',
          'MEMZ',
          'Locky',
          'Loveletter']


ti_list = ['Morris Worm',
           'Nimda',
           'ILOVEYOU',
           'SQL Slammer',
           'Stuxnet',
           'CryptoLocker',
           'Conficker',
           'Tinba',
           'Welchia',
           'Shlayer',
           'Mydoom',
           'Sobig',
           'Klez',
           'WannaCry',
           'Zeus',
           'Code Red',
           'Slammer',
           'CryptoLocker',
           'Sasser',
           'Mimail',
           'Yaha',
           'Swen',
           'Storm Worm',
           'Tanatos',
           'Sircam',
           'Explorezip',
           'Melissa',
           'Flashback',
           'Conficker',
           'X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*',
           'Stuxnet',
           'Torpig',
           'MEMZ',
           'Locky',
           'Loveletter']

at_list_winf = ['CreateFileW',
                'DeleteFileW',
                'FindExistFileW',
                'FindNextFileW',
                'ReadFile',
                'WriteFile',
                'MapViewOfFile',
                'SetFilePointer',
                'CreateDirectoryW',
                'FindClose',
                'SetWindowHookEx',
                'ExitProcess',
                'GetCurrentProcess',
                'GetProcessHeap',
                'OpenProcess',
                'IsDebuggerPresent',
                'CreateThread',
                'GetCurrentThread',
                'GetModuleHandleW',
                'BeginDeferWindowPos',
                'CreateDialogParaW',
                'CreateWindowExW',
                'GetWindowLongW',
                'GetWindowRect',
                'GetWindowTextW',
                'InvalidRect',
                'SetWindowTextW',
                'ShowWindow',
                'RegisterClassExW',
                'RegisterHotKey',
                'RegOpenKeyExW',
                'RegOpenCurrentUser',
                'RegSetValueExW',
                'MessageBoxW']

ai_list_file = ['CreateFileW'
                'DeleteFileW'
                'FindExistFileW'
                'FindNextFileW'
                'ReadFile'
                'WriteFile'
                'MapViewOfFile'
                'SetFilePointer'
                'CreateDirectoryW'
                'FindClose'
                'GetModuleHandleW']

ai_list_process = ['ExitProcess',
                   'GetCurrentProcess',
                   'GetProcessHeap',
                   'OpenProcess']

ai_list_Antidebug = ['IsDebuggerPresent']

ai_list_thread = ['CreateThread',
                  'GetCurrentThread']

ai_list_windows = ['MessageBoxW',
                   'BeginDeferWindowPos',
                   'CreateDialogParaW',
                   'CreateWindowExW',
                   'GetWindowLongW',
                   'GetWindowRect',
                   'GetWindowTextW',
                   'InvalidRect'
                   'SetWindowTextW'
                   'ShowWindow']

ai_list_regkey = ['RegisterClassExW'
                  'RegisterHotKey',
                  'RegOpenKeyExW',
                  'RegOpenCurrentUser',
                  'RegSetValueExW']

ai_list_hook = ['SetWindowHookEx']

at = 34
t = 35
ti = 35
